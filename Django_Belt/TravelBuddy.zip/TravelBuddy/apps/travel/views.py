from django.shortcuts import render, redirect
from django.contrib import messages
import bcrypt
from .models import User, Trip

def index(request):
    return render(request, 'index.html')


def login(request):
    errors = User.objects.validate_login(request.POST)
    if len(errors):
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        user = User.objects.get(email=request.POST['email'])
        request.session['id'] = user.id
        return redirect('/dashboard')


def logout(request):
    request.session.clear()
    return redirect('/')


def register(request):
    errors = User.objects.validate_register(request.POST)
    if len(errors):
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        user = User.objects.create(
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            email = request.POST['email'],
            password = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt())
        )
        request.session['id'] = user.id
        messages.success(request, "New User Created")
        return redirect('/dashboard')


def dashboard(request):
    user = User.objects.get(id=request.session['id'])
    context = {
        'other_trips': Trip.objects.exclude(planner=user).exclude(others=user),
        'user': user,
        'user_trips': Trip.objects.filter(planner=user),
        'user_other_trips': Trip.objects.filter(others=user)
    }
    return render(request, 'dashboard.html', context)


def add(request):
    return render(request, 'add.html')


def create(request):
    errors = Trip.objects.validate_trip(request.POST)

    if len(errors):
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/add')
    else:
        start_date, end_date = Trip.objects.get_dates(request.POST)
        Trip.objects.create(
            destination = request.POST['destination'],
            description = request.POST['description'],
            start_date = start_date,
            end_date = end_date,
            planner = User.objects.get(id=request.session['id'])
        )
        messages.success(request, "New Trip Created")
        return redirect('/dashboard')


def display(request, id):
    context = {
        'others': User.objects.filter(joins=id),
        'trip': Trip.objects.get(id=id)
    }
    return render(request, 'display.html', context)


def delete(request, id):
    user = User.objects.get(id=request.session['id'])
    trip = Trip.objects.get(id=id)
    if trip.planner == user:
        trip.delete()

    return redirect('/dashboard')


def cancel(request, id):
    user = User.objects.get(id=request.session['id'])
    trip = Trip.objects.get(id=id)
    trip.others.remove(user)
    trip.save()
    return redirect('/dashboard')


def join(request, id):
    user = User.objects.get(id=request.session['id'])
    trip = Trip.objects.get(id=id)
    trip.others.add(user)
    trip.save()
    return redirect('/dashboard')
