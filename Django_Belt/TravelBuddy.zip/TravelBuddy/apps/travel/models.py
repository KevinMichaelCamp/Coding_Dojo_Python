from django.db import models
from datetime import datetime
import bcrypt
import datetime as dt
import re

NAME_REGEX = re.compile(r'[a-zA-Z\s]+$')
EMAIL_REGEX = re.compile(r'[a-zA-Z0-9.+_-]+@[a-zA_Z0-9._-]+\.[a-zA-z]+$')

class UserManager(models.Manager):
    def validate_login(self, postData):
        errors = {}

        if 'email' not in postData or 'password' not in postData:
            errors['forms'] = "Quit messin' witht the forms"
            return errors

        if len(User.objects.filter(email=postData['email'])):
            user = User.objects.get(email=postData['email'])
            if bcrypt.checkpw(postData['password'].encode(), user.password):
                return errors
            else:
                errors['login'] = "Invalid email/password"
                return errors
        else:
            errors['login'] = "Invalid email/password"
            return errors

    def validate_register(self, postData):
        errors =  {}

        if 'first_name'not in postData or 'last_name' not in postData or 'email' not in postData or 'password' not in postData or 'pw_confirm' not in postData:
            errors['forms'] = "Quit messin' with the forms"
            return errors

        if len(postData['first_name']) < 2:
            errors['first_name'] = "First name must be at least 2 characters"
        elif not NAME_REGEX.match(postData['first_name']):
            errors['first_name'] = "First name must only contain letters"

        if len(postData['last_name']) < 2:
            errors['last_name'] = "Last name must be at least 2 characters"
        elif not NAME_REGEX.match(postData['last_name']):
            errors['last_name'] = "Last name must only contain letters"

        if not EMAIL_REGEX.match(postData['email']):
            errors['email'] = "Invalid emai format"
        elif len(User.objects.filter(email=postData['email'])):
            errors['email'] = "Email already in use"

        if len(postData['password']) < 8:
            errors['password'] = "Password must be at least 8 characters"
        if postData['password'] != postData['pw_confirm']:
            errors['pw_confirm'] = "Password must match confirmation"

        return errors

class TripManager(models.Manager):
    def get_dates(self, postData):
        start_date = datetime.strptime(postData['start_date'], '%Y-%m-%d')
        end_date = datetime.strptime(postData['end_date'], '%Y-%m-%d')
        return start_date.date(), end_date.date()

    def validate_trip(self, postData):
        errors = {}

        if postData['start_date'] == '' or postData['end_date'] == '':
            errors['dates'] = "Dates can't be blank"
            return errors

        if 'start_date' not in postData or 'end_date' not in postData or 'destination' not in postData or 'description' not in postData:
            errors['forms'] = "Quit messin' with the forms"
            return errors

        start_date = datetime.strptime(postData['start_date'], '%Y-%m-%d')
        end_date = datetime.strptime(postData['end_date'], '%Y-%m-%d')

        if len(postData['destination']) < 1:
            errors['destination'] = "Destination can't be blank"

        if len(postData['description']) < 1:
            errors['description'] = "Description can't be blank"

        if start_date.date() < dt.date.today():
            errors['start_date'] = "Start date must be future date"
        if postData['end_date'] < postData['start_date']:
            errors['end_date'] = "Travel end date must be after start date"

        return errors


class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.BinaryField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __repr__(self):
        return "<User object: {} {} {}".format(self.first_name, self.last_name, self.email)

    objects = UserManager()


class Trip(models.Model):
    destination = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    start_date = models.DateField(null=False, blank=False)
    end_date = models.DateField(null=False, blank=False)
    planner = models.ForeignKey(User, related_name='trips', on_delete=models.PROTECT)
    others = models.ManyToManyField(User, related_name='joins')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __repr__(self):
        return "<Trip object: {} {} {} {} {}".format(self.destination, self.description, self.start_date, self.end_date, self.planner)

    objects = TripManager()
