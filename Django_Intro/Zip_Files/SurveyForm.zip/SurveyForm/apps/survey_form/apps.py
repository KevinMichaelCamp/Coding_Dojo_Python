from django.apps import AppConfig


class SurveyFormConfig(AppConfig):
    name = 'survey_form'
