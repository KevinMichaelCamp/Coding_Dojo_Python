from django.apps import AppConfig


class FileUploadConfig(AppConfig):
    name = 'file_upload'
